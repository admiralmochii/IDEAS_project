export default function Test() {
  return (
    <div style={{ padding: 40 }}>
      <h1 style={{ color: "#ffffff" }}>Schedule Page</h1>
      <p style={{ color: "#ffffff" }}>Schedule stuff</p>
    </div>
  );
}
