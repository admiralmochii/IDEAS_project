export default function Test() {
  return (
    <div style={{ padding: 40 }}>
      <h1 style={{ color: "#ffffff" }}>User Page</h1>
      <p style={{ color: "#ffffff" }}>The user page</p>
    </div>
  );
}
